
import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class RESTfulClient {
	
	//String link = "http://192.168.150.34:8888";
	String link = "http://localhost:8888"; // Inserir o IP aqui
	
	public void recuperar_usuarios(String param) {
		 try {
			 URL url;
			 	if (param == "") {
			 		url = new URL(link);
			 	}else {
			 		url = new URL(link + "?rg=" + param);
			 	}
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				con.setRequestMethod("GET");
				con.setRequestProperty("Accept", "text/json");

				if (con.getResponseCode() != 200) {
					throw new RuntimeException("Erro " + con.getResponseCode());
				}

				BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));

				String output;
				while ((output = br.readLine()) != null) {
					output = output.replace("}, ", "\n");
					output = output.replace("[", "").replace("{", "").replace("\"", "").replace("}", "").replace("]", "");
					System.out.println(output);
				}

				con.disconnect();

			  } catch (MalformedURLException e) {

				e.printStackTrace();

			  } catch (IOException e) {

				e.printStackTrace();

			  }
	}
	
	public void request_GET(String rg, String senha) {
		 try {
			 	URL url = new URL(link + "?rg=" + rg + "&senhaAtual=" + senha );
	
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				con.setRequestMethod("GET");
				con.setRequestProperty("Accept", "text/json");

				if (con.getResponseCode() != 200) {
					throw new RuntimeException("Falha: Erro " + con.getResponseCode());
				}

				BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));

				String output;
				while ((output = br.readLine()) != null) {
					System.out.println(output);
				}

				con.disconnect();

			  } catch (MalformedURLException e) {

				e.printStackTrace();

			  } catch (IOException e) {

				e.printStackTrace();

			  }
	}
	
	public void adicionar_usuario(String nome, String rg, String matricula, String endereco, String senha){
		try {
		 	URL url = new URL(link);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("Accept", "text/json");
			
			con.setDoOutput(true);
			String input = "{\"nome\":" + "\""  + nome + "\"" + "," +" \"rg\":" + rg + "," +"\"matricula\":" + matricula + "," + "\"endereco\":" + "\"" + endereco + "\"" + "," + "\"senha\":" + "\"" + senha + "\"" + "}";
			OutputStream os = con.getOutputStream();
			os.write(input.getBytes());
			os.flush();
			os.close();

			if (con.getResponseCode() != 200) {
				throw new RuntimeException("Falha: Erro " + con.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));

			String output;
			while ((output = br.readLine()) != null) {
				System.out.println(output);
			}

			con.disconnect();

		  } catch (MalformedURLException e) {

			e.printStackTrace();

		  } catch (IOException e) {

			e.printStackTrace();

		  }
	}
	
	public void alterar_dados(String rg1, String nome, String rg2, String matricula, String endereco){
		try {
		 	URL url = new URL(link + "?rg=" + rg1);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("PUT");
			con.setRequestProperty("Accept", "text/json");
			
			con.setDoOutput(true);
			String input = "{\"nome\":" + "\""  + nome + "\"" + "," +" \"rg\":" + rg2 + "," +"\"matricula\":" + matricula + "," + "\"endereco\":" + "\"" + endereco + "\"" + "}";
			// String input = "{\"nome\":" + "\""  + nome + "\"" + "," +" \"rg\":" + rg2 + "," +"\"matricula\":" + matricula + "," + "\"endereco\":" + "\"" + endereco + "\"" + "," + "\"senha\":" + "\"" + senha + "\"" + "}";
			OutputStream os = con.getOutputStream();
			os.write(input.getBytes());
			os.flush();
			os.close();

			if (con.getResponseCode() != 200) {
				throw new RuntimeException("Falha: Erro " + con.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));

			String output;
			while ((output = br.readLine()) != null) {
				System.out.println(output);
			}

			con.disconnect();

		  } catch (MalformedURLException e) {

			e.printStackTrace();

		  } catch (IOException e) {

			e.printStackTrace();

		  }
	}
	
	public void alterar_senha(String rg1, String senhaAtual, String senhaNova){
		try {
		 	URL url = new URL(link + "?rg=" + rg1);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("PUT");
			con.setRequestProperty("Accept", "text/json");
			
			con.setDoOutput(true);
			String input = "{\"senhaAtual\":" + "\""  + senhaAtual + "\"" + "," + "\"senhaNova\":" +  "\"" + senhaNova + "\"" + "}";
			OutputStream os = con.getOutputStream();
			os.write(input.getBytes());
			os.flush();
			os.close();

			if (con.getResponseCode() != 200) {
				throw new RuntimeException("Falha: Erro " + con.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));

			String output;
			while ((output = br.readLine()) != null) {
				System.out.println(output);
			}

			con.disconnect();

		  } catch (MalformedURLException e) {

			e.printStackTrace();

		  } catch (IOException e) {

			e.printStackTrace();

		  }
	}
	
	public void deletar_usuario(String param){
		try {
			 	URL url = new URL(link + "?rg=" + param);
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				con.setRequestMethod("DELETE");
				con.setRequestProperty("Accept", "text/json");

				if (con.getResponseCode() != 200) {
					throw new RuntimeException("Falha: Erro " + con.getResponseCode());
				}

				BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));

				String output;
				while ((output = br.readLine()) != null) {
					System.out.println(output);
				}

				con.disconnect();

			  } catch (MalformedURLException e) {

				e.printStackTrace();

			  } catch (IOException e) {

				e.printStackTrace();

			  }
	}

	public static void main(String[] args) {
		RESTfulClient client = new RESTfulClient();
		Scanner sc = new Scanner(System.in);
		
		int aux = 0;
		do {
			System.out.println("MENU DE OPCOES:\n" 
			        + "1 - Adicionar usu�rio\n2 - Listar usu�rios cadastrados\n3 - Alterar dados de um usu�rio\n4 - Visualizar dados de um usu�rio\n"
			        + "5 - Alterar senha de usu�rio\n6 - Verificar se a senha est� correta\n7 - Remover usu�rio\n0 - Sair");
			
	        int opcao = sc.nextInt();
	        aux = opcao;
			
			switch (opcao) {		
			case 1:
				sc.nextLine(); //Esvazia o buffer
				System.out.println("Nome: ");
				String nome1 = sc.nextLine();
				System.out.println("RG: ");
				String rg1 = sc.nextLine();
				System.out.println("Matricula: ");
				String matricula1 = sc.nextLine();
				System.out.println("Endereco: ");
				String endereco1 = sc.nextLine();
				System.out.println("Senha: ");
				String senha1 = sc.nextLine();
				
				client.adicionar_usuario(nome1, rg1, matricula1, endereco1, senha1);
				System.out.println("\n");
				break;	
				
			case 2:
				client.recuperar_usuarios("");
				System.out.println("\n");
				break;
				
			case 3:
				sc.nextLine(); //Esvazia o buffer
				System.out.println("Digite o RG cadastrado do usuario: ");
				String rg31 = sc.nextLine();
				System.out.println("Digite as novas informa��es do usu�rio: ");
				
				System.out.println("Nome: ");
				String nome3 = sc.nextLine();
				System.out.println("RG: ");
				String rg32 = sc.nextLine();
				System.out.println("Matricula: ");
				String matricula3 = sc.nextLine();
				System.out.println("Endereco: ");
				String endereco3 = sc.nextLine();
				
				client.alterar_dados(rg31, nome3, rg32, matricula3, endereco3);
				System.out.println("\n");
				break;
				
			case 4:
				sc.nextLine(); //Esvazia o buffer
				System.out.println("Digite o RG do usu�rio: ");
				String rg4 = sc.nextLine();
				
				client.recuperar_usuarios(rg4);
				System.out.println("\n");
				break;
				
			case 5:
				sc.nextLine(); //Esvazia o buffer
				System.out.println("Digite o RG do usu�rio: ");
				String rg5 = sc.nextLine();
				System.out.println("Digite a senha atual: ");
				String senhaAtual = sc.nextLine();
				System.out.println("Digite a nova senha: ");
				String senhaNova = sc.nextLine();
				
				client.alterar_senha(rg5, senhaAtual, senhaNova );
				System.out.println("\n");
				break;
			
			case 6:
				sc.nextLine(); //Esvazia o buffer
				System.out.println("Digite o RG do usu�rio: ");
				String rg6 = sc.nextLine();
				System.out.println("Digite a senha: ");
				String senha6 = sc.nextLine();
				
				client.request_GET(rg6, senha6);
				System.out.println("\n");
				break;
				
			case 7:
				sc.nextLine(); //Esvazia o buffer
				System.out.println("Digite o RG do usu�rio: ");
				String rg7 = sc.nextLine();
				client.deletar_usuario(rg7);
				System.out.println("\n");
				break;
				
			case 0:
				System.out.println("Conex�o encerrada.");
				System.out.println("\n");
				break;	

			default:
				System.out.println( "Opcao invalida!" );
				System.out.println("\n");
				break;
			}
		}while(aux != 0);
	}

}